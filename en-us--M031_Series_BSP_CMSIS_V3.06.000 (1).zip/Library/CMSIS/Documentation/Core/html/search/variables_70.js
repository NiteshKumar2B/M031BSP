var searchData=
[
  ['pcsr',['PCSR',['../struct_d_w_t___type.html#a6353ca1d1ad9bc1be05d3b5632960113',1,'DWT_Type']]],
  ['pfr',['PFR',['../struct_s_c_b___type.html#a681c9d9e518b217976bef38c2423d83d',1,'SCB_Type']]],
  ['port',['PORT',['../struct_i_t_m___type.html#af4c205be465780a20098387120bdb482',1,'ITM_Type']]]
];
